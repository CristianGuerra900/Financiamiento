package com.app.dao;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.app.model.Socio;

public interface SocioDao extends JpaRepository<Socio, Long> {
	
	@Query("SELECT s FROM Socio s WHERE s.montoMaximoDisponible >= ?1 ORDER BY s.taza")
	List<Socio> getSocioConMinimaTaza(double montoPrestamo, Pageable pageable);

}
