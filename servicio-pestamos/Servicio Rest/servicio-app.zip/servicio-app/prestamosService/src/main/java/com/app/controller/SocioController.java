package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.ErrorDto;
import com.app.dto.PrestamoDto;
import com.app.model.Socio;
import com.app.service.SocioService;

@RestController
@RequestMapping(path="/api")
public class SocioController {
	
	@Autowired
	private SocioService socioService;
	
	@GetMapping("/socio")
	public List<Socio> findAll() {
		return this.socioService.findAll();
	}

	@GetMapping("/prestamo/{cantidadPrestamo}")
	public ResponseEntity<?> getPrestamo(@PathVariable double cantidadPrestamo) {
		try {
			PrestamoDto prestamoDto = this.socioService.calcularPrestamo(cantidadPrestamo);
			return new ResponseEntity<PrestamoDto>(prestamoDto, HttpStatus.OK);
		} catch (Exception e) {
			ErrorDto error = new ErrorDto();
			error.setMessage(e.getMessage());
			return new ResponseEntity<ErrorDto>(error, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
