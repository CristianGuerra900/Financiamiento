package com.app.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="socios")
public class Socio implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	
	private String nombre;
	
	private Double taza;
	
	@Column(name="monto_maximo_disponible")
	private Double montoMaximoDisponible;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Double getTaza() {
		return taza;
	}

	public void setTaza(Double taza) {
		this.taza = taza;
	}

	public Double getMontoMaximoDisponible() {
		return montoMaximoDisponible;
	}

	public void setMontoMaximoDisponible(Double montoMaximoDisponible) {
		this.montoMaximoDisponible = montoMaximoDisponible;
	}
	
	
	
}
