package com.app.dto;

import java.io.Serializable;

import com.app.model.Socio;

public class PrestamoDto implements Serializable, ResponseData {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Socio socio;
	private String cuotaMensual;
	private String pagoTotal;
	
	public PrestamoDto() {
		super();
	}
	
	
	public Socio getSocio() {
		return socio;
	}
	public void setSocio(Socio socio) {
		this.socio = socio;
	}
	public String getCuotaMensual() {
		return cuotaMensual;
	}
	public void setCuotaMensual(String cuotaMensual) {
		this.cuotaMensual = cuotaMensual;
	}
	public String getPagoTotal() {
		return pagoTotal;
	}
	public void setPagoTotal(String pagoTotal) {
		this.pagoTotal = pagoTotal;
	}
	
}
