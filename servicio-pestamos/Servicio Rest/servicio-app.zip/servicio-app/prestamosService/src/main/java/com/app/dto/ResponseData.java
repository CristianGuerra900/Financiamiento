package com.app.dto;

public interface ResponseData {

}
