package com.app.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.app.dao.SocioDao;
import com.app.dto.PrestamoDto;
import com.app.model.Socio;
import com.app.utils.Redondeo;

@Service
public class SocioService {

	@Autowired
	private SocioDao socioDao;

	public List<Socio> findAll() {
		return this.socioDao.findAll();
	}

	public PrestamoDto calcularPrestamo(Double cantidadPrestamo) throws Exception {
		PrestamoDto prestamoDto = new PrestamoDto();

		try {

			Socio socioMinimaTaza = this.obtenerSocioMinimaTaza(cantidadPrestamo);
			prestamoDto.setPagoTotal(this.calularValorTotal(cantidadPrestamo));
			prestamoDto.setCuotaMensual(this.calcularCuotasPrestamos(prestamoDto.getPagoTotal()));
			prestamoDto.setSocio(socioMinimaTaza);

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

		return prestamoDto;
	}

	private Socio obtenerSocioMinimaTaza(Double cantidadPrestamo) throws Exception {
		Socio socio = null;
		List<Socio> listSocios = this.socioDao.getSocioConMinimaTaza(cantidadPrestamo, PageRequest.of(0, 1));

		if (listSocios == null || listSocios.size() == 0) {
			throw new Exception("No hay socio disponible");
		} else {
			socio = listSocios.get(0);
		}

		return socio;
	}

	private String calularValorTotal(Double cantidadPrestamo) throws Exception {
		try {
			return "6160000";
		} catch (Exception e) {
			throw new Exception("Ocurrio un error al realizar el calculo de la cuenta total");
		}
	}

	private String calcularCuotasPrestamos(String cantidadPrestamo) throws Exception {
		try {
			Double cantidad = Redondeo.round((Double.parseDouble(cantidadPrestamo) / 36), 2);
			return String.valueOf(cantidad);
		} catch (Exception e) {
			throw new Exception("Ocurrio un error al realizar el calculo de las cuotas");
		}
	}

}
