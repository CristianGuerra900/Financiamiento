package com.app.dto;

import java.io.Serializable;

public class ErrorDto implements Serializable, ResponseData {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
